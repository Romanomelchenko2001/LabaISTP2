﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Laba22ISTP.Models;

namespace Laba22ISTP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShinobisController : ControllerBase
    {
        private readonly NarutoContext _context;

        public ShinobisController(NarutoContext context)
        {
            _context = context;
        }

        // GET: api/Shinobis
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Shinobi>>> GetShinobis()
        {
            return await _context.Shinobis.ToListAsync();
        }

        // GET: api/Shinobis/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Shinobi>> GetShinobi(int id)
        {
            var shinobi = await _context.Shinobis.FindAsync(id);

            if (shinobi == null)
            {
                return NotFound();
            }

            return shinobi;
        }

        // PUT: api/Shinobis/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutShinobi(int id, Shinobi shinobi)
        {
            if (id != shinobi.ShinobiID
                ||( !RankExists(shinobi.ShinobiRankID)) 
                || (!TeamExists(shinobi.ShinobiTeamID)) 
                || (ShinobiNameCheck(shinobi)) 
                || (!VillageExists(shinobi.ShinobiVillageID)))
            {
                return BadRequest();
            }

            _context.Entry(shinobi).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ShinobiExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Shinobis
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Shinobi>> PostShinobi(Shinobi shinobi)
        {

            if (RankExists(shinobi.ShinobiRankID)&&TeamExists(shinobi.ShinobiTeamID)&&ShinobiNameCheck(shinobi)&&VillageExists(shinobi.ShinobiVillageID))
            {
                shinobi.ShinobiRankName = _context.Ranks.Find(shinobi.ShinobiRankID).RankName;
                _context.Shinobis.Add(shinobi);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetShinobi", new { id = shinobi.ShinobiID }, shinobi);
            }
            return null;
        }

        // DELETE: api/Shinobis/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Shinobi>> DeleteShinobi(int id)
        {
            var shinobi = await _context.Shinobis.FindAsync(id);
            if (shinobi == null)
            {
                return NotFound();
            }

            _context.Shinobis.Remove(shinobi);
            await _context.SaveChangesAsync();

            return shinobi;
        }

        private bool ShinobiExists(int id)
        {
            return _context.Shinobis.Any(e => e.ShinobiID == id);
        }
        private bool ShinobiExists(string id)
        {
            return _context.Shinobis.Any(e => e.ShinobiName == id);
        }
        private bool RankExists(int id)
        {
            return _context.Ranks.Any(e => e.RankID == id);
        }
        private bool TeamExists(int id)
        {
            return _context.Teams.Any(e => e.TeamID == id);
        }
        private bool VillageExists(int id)
        {
            return _context.Villages.Any(e => e.VillageID == id);
        }
        private bool ShinobiNameCheck(Shinobi shinobi)
        {
            bool flag = false;

            for (int i = 0; i < shinobi.ShinobiName.Length; i++)
            {
                if (CountriesController.forbidden_symbols.IndexOf(shinobi.ShinobiName[i]) != -1)
                {
                    flag = true;
                    break;
                }
                if (shinobi.ShinobiName[0] == ' ' || shinobi.ShinobiName[1] == ' ' || shinobi.ShinobiName[shinobi.ShinobiName.Length - 1] == ' ' || shinobi.ShinobiName[shinobi.ShinobiName.Length - 1] == ' ')
                {
                    flag = true;
                    break;
                }

            }
            if (!flag)
            {
                for (int i = 1; i < shinobi.ShinobiName.Length - 1; i++)
                {
                    if (shinobi.ShinobiName[i - 1] == ' ' && shinobi.ShinobiName[i] != ' ' && shinobi.ShinobiName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                shinobi.ShinobiName = shinobi.ShinobiName.ToUpper();
                if (ShinobiExists(shinobi.ShinobiName))
                {
                    flag = true;
                }

            }
            return flag;
        }
    }
}
