﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Laba22ISTP.Models;

namespace Laba22ISTP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RanksController : ControllerBase
    {
        private readonly NarutoContext _context;

        public RanksController(NarutoContext context)
        {
            _context = context;
        }

        // GET: api/Ranks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Rank>>> GetRanks()
        {
            return await _context.Ranks.ToListAsync();
        }

        // GET: api/Ranks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Rank>> GetRank(int id)
        {
            var rank = await _context.Ranks.FindAsync(id);

            if (rank == null)
            {
                return NotFound();
            }

            return rank;
        }

        // PUT: api/Ranks/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRank(int id, Rank rank)
        {
            if (id != rank.RankID&&RankCheck(rank))
            {
                return BadRequest();
            }

            _context.Entry(rank).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RankExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Ranks
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Rank>> PostRank(Rank rank)
        {
            bool flag = RankCheck(rank);
            if (!flag)
            {
                _context.Ranks.Add(rank);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetRank", new { id = rank.RankID }, rank);
            }
            return null;
        }

        // DELETE: api/Ranks/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Rank>> DeleteRank(int id)
        {
            var rank = await _context.Ranks.FindAsync(id);
            if (rank == null)
            {
                return NotFound();
            }

            _context.Ranks.Remove(rank);
            await _context.SaveChangesAsync();

            return rank;
        }

        private bool RankExists(int id)
        {
            return _context.Ranks.Any(e => e.RankID == id);
        }
        private bool RankExists(string id)
        {
            return _context.Ranks.Any(e => e.RankName == id);
        }
        private bool RankCheck(Rank rank)
        {
            bool flag = false;
            if (rank.RankName.Length<4)
            {
                return true;
            }
            for (int i = 0; i < rank.RankName.Length; i++)
            {
                if (CountriesController.forbidden_symbols.IndexOf(rank.RankName[i]) != -1)
                {
                    flag = true;
                    break;
                }
                if (rank.RankName[0] == ' ' || rank.RankName[1] == ' ' || rank.RankName[rank.RankName.Length - 1] == ' ' || rank.RankName[rank.RankName.Length - 1] == ' ')
                {
                    flag = true;
                    break;
                }

            }
            if (!flag)
            {
                for (int i = 1; i < rank.RankName.Length - 1; i++)
                {
                    if (rank.RankName[i - 1] == ' ' && rank.RankName[i] != ' ' && rank.RankName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                rank.RankName = rank.RankName.ToUpper();
                if (RankExists(rank.RankName))
                {
                    flag = true;
                }

            }

            if (!flag)
            {
                string check = "NIN";
                int j = 0;
                for (int i = rank.RankName.Length-3; i < rank.RankName.Length; i++)
                {
                    if (rank.RankName[i]!=check[j])
                    {
                        flag = true;
                        break;
                    }
                    j++;
                }
            }
            return flag;
        }
    }
}
