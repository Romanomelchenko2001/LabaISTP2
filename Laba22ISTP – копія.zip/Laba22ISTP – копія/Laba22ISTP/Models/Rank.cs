﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba22ISTP.Models
{
    public class Rank
    {
        public Rank()
        {
            Shinobis = new List<Shinobi>(); 
        }
        public int RankID { get; set; }
        [Display(Name = "Ранг")]
        [Required(ErrorMessage = "Ранг шинобі не може бути порожнім")]
        public string RankName { get; set; }
        
        public ICollection<Shinobi> Shinobis { get; set; }


    }
}
