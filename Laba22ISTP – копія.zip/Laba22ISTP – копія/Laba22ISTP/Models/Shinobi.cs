﻿using System;
using System.ComponentModel.DataAnnotations;
namespace Laba22ISTP.Models
{
    public class Shinobi
    {
        public int ShinobiID { get; set; }
        [Display(Name = "Ім'я шинобі")]
        [Required(ErrorMessage = "Ім'я країни не може бути порожнім")]
        public string ShinobiName { get; set; }
        [Display(Name ="Info")]
        public string ShinobiInfo { get; set; }
        public string ShinobiRankName { get; set; }
        public int ShinobiRankID { get; set; }
        //[Display(Name = "Назва команди")]
        //[Required(ErrorMessage = "Назва команди не може бути порожньою")]
        //public virtual Team ShinobiTeam { get; set; }
        public int ShinobiVillageID { get; set; }
        public int ShinobiTeamID { get; set; }
        //public string ShinobiRank { get; set; }
    }
}
