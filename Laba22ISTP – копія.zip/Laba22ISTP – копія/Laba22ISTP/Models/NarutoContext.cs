﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Laba22ISTP.Models
{
    public class NarutoContext:DbContext
    {
        public NarutoContext(DbContextOptions<NarutoContext> options):base(options)
        {
            Database.EnsureCreated();
        }
            public virtual DbSet<Country> Countries { get; set; }

            public virtual DbSet<Rank> Ranks { get; set; }

            public virtual DbSet<Shinobi> Shinobis { get; set; }
        public virtual DbSet<Team> Teams { get; set; }
        public virtual DbSet<Village> Villages { get; set; }
    }
}
