﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba22ISTP.Models
{
    public class Country
    {
        public Country()
        {
            Villages = new List<Village>();
        }

        public int CountryID { get; set; }
        [Display(Name = "Країна")]
        [Required(ErrorMessage = "Ім'я країни не може бути порожнім")]
        public string CountryName { get; set; }
        public virtual ICollection<Village> Villages { get; set; }
    }
}
