﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba22ISTP.Models
{
    public class Team
    {
        public Team()
        {
            Shinobis = new List<Shinobi>();
        }
        public int TeamID { get; set;}
        [Display(Name = "Команда")]
        [Required(ErrorMessage = "назва команди не може бути порожньою")]
        public int TeamNumber { get; set; }
        public virtual ICollection<Shinobi> Shinobis { get; set; }
        //[Display(Name = "Лідер команди")]
        //[Required(ErrorMessage = "Команді потрібен лідер")]
        //public int LeaderId { get; set; }
    }
}
