﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Laba22ISTP.Models;

namespace Laba22ISTP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VillagesController : ControllerBase
    {
        private readonly NarutoContext _context;

        public VillagesController(NarutoContext context)
        {
            _context = context;
        }

        // GET: api/Villages
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Village>>> GetVillages()
        {
            return await _context.Villages.ToListAsync();
        }

        // GET: api/Villages/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Village>> GetVillage(int id)
        {
            var village = await _context.Villages.FindAsync(id);

            if (village == null)
            {
                return NotFound();
            }

            return village;
        }

        // PUT: api/Villages/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVillage(int id, Village village)
        {
            if (id != village.VillageID||VillageCheck(village))
            {
                return BadRequest();
            }

            _context.Entry(village).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VillageExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Villages
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Village>> PostVillage(Village village)
        {
            bool flag = false;

            for (int i = 0; i < village.VillageName.Length; i++)
            {
                if (CountriesController.forbidden_symbols.IndexOf(village.VillageName[i]) != -1)
                {
                    flag = true;
                    break;
                }
                if (village.VillageName[0] == ' ' || village.VillageName[1] == ' ' || village.VillageName[village.VillageName.Length - 1] == ' ' || village.VillageName[village.VillageName.Length - 1] == ' ')
                {
                    flag = true;
                    break;
                }

            }
            if (!flag)
            {
                for (int i = 1; i < village.VillageName.Length - 1; i++)
                {
                    if (village.VillageName[i - 1] == ' ' && village.VillageName[i] != ' ' && village.VillageName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                village.VillageName = village.VillageName.ToUpper();
                if (VillageExists(village.VillageName))
                {
                    flag = true;
                }

            }

            if (!flag)
            {
                for (int i = 1; i < village.VillageName.Length - 1; i++)
                {
                    if (village.VillageName[i - 1] == ' ' && village.VillageName[i] != ' ' && village.VillageName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }

            if (!flag)
            {
                if (VillageLeaderExists(village.VillageLeaderName))
                {
                    flag = true;
                }
            }
            if (!flag)
            {
                flag = _leaderNameCheck(village);
            }

            if (!flag)
            {
                village.VillageCountry = _context.Countries.Find(village.VillageCountryID);
                _context.Villages.Add(village);
                await _context.SaveChangesAsync();
            }
            return CreatedAtAction("GetVillage", new { id = village.VillageID }, village);
        }

        // DELETE: api/Villages/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Village>> DeleteVillage(int id)
        {
            var village = await _context.Villages.FindAsync(id);
            if (village == null)
            {
                return NotFound();
            }

            _context.Villages.Remove(village);
            await _context.SaveChangesAsync();

            return village;
        }

        private bool VillageExists(int id)
        {
            return _context.Villages.Any(e => e.VillageID == id);
        }
        private bool VillageExists(string id)
        {
            return _context.Villages.Any(e => e.VillageName == id);
        }
        private bool VillageLeaderExists(string id)
        {
            return _context.Villages.Any(e => e.VillageLeaderName == id);
        }
        private bool _leaderNameCheck(Village village)
        {
            bool flag = false;
            if (village.VillageLeaderName.Length<=4)
            {
                flag = true;
            }
            if (!flag)
            {
                for (int i = 0; i < village.VillageLeaderName.Length; i++)
                {
                    if (CountriesController.forbidden_symbols.IndexOf(village.VillageName[i]) != -1)
                    {
                        flag = true;
                        break;
                    }
                    if (village.VillageLeaderName[0] == ' ' || village.VillageLeaderName[1] == ' ' || village.VillageLeaderName[village.VillageLeaderName.Length - 1] == ' ' || village.VillageLeaderName[village.VillageLeaderName.Length - 1] == ' ')
                    {
                        flag = true;
                        break;
                    }

                }
            }
            
            if (!flag)
            {
                for (int i = 1; i < village.VillageLeaderName.Length - 1; i++)
                {
                    if (village.VillageLeaderName[i - 1] == ' ' && village.VillageLeaderName[i] != ' ' && village.VillageLeaderName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                village.VillageLeaderName = village.VillageLeaderName.ToUpper();
                if (VillageExists(village.VillageLeaderName))
                {
                    flag = true;
                }

            }

            if (!flag)
            {
                for (int i = 1; i < village.VillageLeaderName.Length - 1; i++)
                {
                    if (village.VillageLeaderName[i - 1] == ' ' && village.VillageLeaderName[i] != ' ' && village.VillageLeaderName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                string test = "KAGE";
                int j = 0;
                for (int i = village.VillageLeaderName.Length-4; i < village.VillageLeaderName.Length; i++)
                {
                    if (village.VillageLeaderName[i]!=test[j])
                    {
                        flag = true;
                    }
                    j++;
                }
            }
            return flag;
        }
        public bool VillageCheck(Village village)
        {
            bool flag = false;

            for (int i = 0; i < village.VillageName.Length; i++)
            {
                if (CountriesController.forbidden_symbols.IndexOf(village.VillageName[i]) != -1)
                {
                    flag = true;
                    break;
                }
                if (village.VillageName[0] == ' ' || village.VillageName[1] == ' ' || village.VillageName[village.VillageName.Length - 1] == ' ' || village.VillageName[village.VillageName.Length - 1] == ' ')
                {
                    flag = true;
                    break;
                }

            }
            if (!flag)
            {
                for (int i = 1; i < village.VillageName.Length - 1; i++)
                {
                    if (village.VillageName[i - 1] == ' ' && village.VillageName[i] != ' ' && village.VillageName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                village.VillageName = village.VillageName.ToUpper();
                if (VillageExists(village.VillageName))
                {
                    flag = true;
                }

            }

            if (!flag)
            {
                for (int i = 1; i < village.VillageName.Length - 1; i++)
                {
                    if (village.VillageName[i - 1] == ' ' && village.VillageName[i] != ' ' && village.VillageName[i + 1] == ' ')
                    {
                        flag = true;
                        break;
                    }
                }
            }

            if (!flag)
            {
                if (VillageLeaderExists(village.VillageLeaderName))
                {
                    flag = true;
                }
            }
            if (!flag)
            {
                flag = _leaderNameCheck(village);
            }
            return flag;
        }
    }
}
