﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba22ISTP.Models
{
    public class Team
    {
        public Team()
        {
            Members = new List<Shinobi>();
        }
        public int TeamId { get; set;}
        [Display(Name = "Команда")]
        [Required(ErrorMessage = "назва команди не може бути порожньою")]
        public string TeamName { get; set; }

        public ICollection<Shinobi> Members { get; set; }
        [Display(Name = "Лідер команди")]
        [Required(ErrorMessage = "Команді потрібен лідер")]
        public Shinobi Leader { get; set; }
    }
}
