﻿using System;
using System.ComponentModel.DataAnnotations;
namespace Laba22ISTP.Models
{
    public class Shinobi
    {
        public int ShinobiID { get; set; }
        [Display(Name = "Ім'я шинобі")]
        [Required(ErrorMessage = "Ім'я країни не може бути порожнім")]
        public string ShinobiName { get; set; }
        [Display(Name = "Назва команди")]
        public string ShinobiInfo { get; set; }
        public Rank ShinobiRank { get; set; }
        public int ShinobiRankID { get; set; }
        [Display(Name = "Назва команди")]
        [Required(ErrorMessage = "Назва команди не може бути порожньою")]
        public Team ShinobiTeam { get; set; }
        public int ShinobiTeamId { get; set; }
        [Display(Name = "Країна")]
        public Village ShinobiVillage { get; set; }
        public int ShinobiVillageId { get; set; }
        //public string ShinobiRank { get; set; }
    }
}
