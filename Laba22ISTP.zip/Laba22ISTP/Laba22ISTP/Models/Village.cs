﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Laba22ISTP.Models
{
    public class Village
    {
        public Village()
        {
            Shinobis = new List<Shinobi>();
        }
        public int VillageID { get; set; }
        [Display(Name = "Назва Селища")]
        [Required(ErrorMessage = "Назва селища не може бути порожнім")]
        public string VillageName { get; set; }
        [Display(Name = "Голова")]
        [Required(ErrorMessage = "Голова селища не може бути порожнім")]
        public string VillageLeaderName { get; set; }//Назва посади голови селища ніндзя, наприклад хокаге(див. джерело)
        [Display(Name = "Назва країни")]
        public Country VillageCountry { get; set; }
        public int VillageCountryID { get; set; }
        public ICollection<Shinobi> Shinobis { get; set; }
    }
}
