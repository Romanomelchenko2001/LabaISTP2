﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Laba22ISTP.Models
{
    public class NarutoContext:DbContext
    {
        public NarutoContext(DbContextOptions<NarutoContext> options):base(options)
        {
            Database.EnsureCreated();
        }
            public DbSet<Country> Countries { get; set; }

            public DbSet<Rank> Ranks { get; set; }

            public DbSet<Shinobi> Shinobis { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Village> Villages { get; set; }
    }
}
